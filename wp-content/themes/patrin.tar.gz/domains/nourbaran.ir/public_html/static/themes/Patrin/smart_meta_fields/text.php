<input type="text" name="<?php echo $id?>" id="<?php echo $id?>" value="<?php echo $value?>" class="regular-text" style="width:90%;" />
