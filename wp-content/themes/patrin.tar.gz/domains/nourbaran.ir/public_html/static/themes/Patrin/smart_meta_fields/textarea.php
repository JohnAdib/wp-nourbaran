<textarea name="<?php echo $id?>" id="<?php echo $id?>" rows="5" cols="50" class="regular-text" style="width:90%;"><?php echo $value?></textarea>
